import React from "react";
import "./FoodList.css";

const foodItems = [
  { description: "Chicken Fried Rice", name: "FriedRice", price: 150 },
  { description: "Mutton Briyani", name: "Briyani", price: 175 },
  { description: "Idly with Vada", name: "Idly", price: 50 },
  { description: "Dosai with potato masala", name: "Dosai", price: 55 },
];

const FoodList = () => {
  return (
    <div className="container">
      {foodItems.map((item, index) => (
        <div key={index} className="food-item">
          <h2 className="food-name">{item.name}</h2>
          <p className="food-description">{item.description}</p>
          <p className="food-price">₹{item.price}.00</p>
        </div>
      ))}
    </div>
  );
};

export default FoodList;
