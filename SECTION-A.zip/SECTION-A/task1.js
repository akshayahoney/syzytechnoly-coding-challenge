function findLongestWords(text) {
    let words = text.match(/\b\w+\b/g); // Extract words using regex
    let maxLength = Math.max(...words.map(word => word.length));

    return words.filter(word => word.length === maxLength);
}

// Example usage:
let text = "This is a coding challenge for the interview process";
console.log(findLongestWords(text)); // Output: ['challenge', 'interview']
