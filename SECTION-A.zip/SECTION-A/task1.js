// Task-1 :Find the longest word/words in the given text

function findLongestWords(text) {
    let words = text.match(/\b\w+\b/g); // Extract words using regex
    let maxLength = Math.max(...words.map(word => word.length));

    return words.filter(word => word.length === maxLength);
}

let text = "This is a coding challenge for the interview process";
console.log(findLongestWords(text));
