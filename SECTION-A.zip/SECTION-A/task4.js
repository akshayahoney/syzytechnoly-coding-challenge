function findIntersection(arr1, arr2) {
    // Filter elements from arr1 that exist in arr2
    return arr1.filter(num => arr2.includes(num));
}
const array1 = [1, 2, 3, 4, 5, 6];
const array2 = [1, 3, 5, 7];
console.log(findIntersection(array1, array2)); 