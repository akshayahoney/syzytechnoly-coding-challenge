function countVowels(word) {
    // Define a set of vowels for quick lookup
    const vowels = new Set(['a', 'e', 'i', 'o', 'u']);
    let vowelCount = 0;
    let vowelChars = [];
    
    // Convert the word to lowercase to handle case insensitivity
    word = word.toLowerCase();
    
    // Loop through each character in the word
    for (let char of word) {
        if (vowels.has(char)) {
            vowelCount++;
            vowelChars.push(char);
        }
    }
    
    return { count: vowelCount, vowels: vowelChars };
}

const word = "Challenge";
const result = countVowels(word);
console.log(`Total vowels: ${result.count} (${result.vowels.join(', ')})`);
