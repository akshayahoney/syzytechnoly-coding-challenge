//Task-2 : Given an array of integers. Find the largest sum of 3 integers

function largestSumOfThreeUnique(arr) {
    // Create a Set to remove duplicates and convert back to an array
    let uniqueArr = [...new Set(arr)];
    
    // Sort the array in descending order
    uniqueArr.sort((a, b) => b - a);
    
    // Ensure there are at least 3 unique numbers
    if (uniqueArr.length < 3) {
        throw new Error("Array must contain at least 3 unique numbers");
    }
    
    // Sum the top 3 numbers
    return uniqueArr[0] + uniqueArr[1] + uniqueArr[2];
}

const arr = [1, 5, 8, 6, 7, 9, 9, 9];
console.log(largestSumOfThreeUnique(arr)); 